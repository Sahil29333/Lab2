// Copyright Epic Games, Inc. All Rights Reserved.

#include "UELab2.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, UELab2, "UELab2" );
